"""
APEX Web API Server — serves the frontend and REST endpoints.
Runs on http://localhost:8080 by default.
Uses only stdlib (http.server) — no FastAPI/Flask dependency.

Endpoints:
  GET  /           → serves index.html
  GET  /state      → full engine state JSON
  GET  /network    → connection status for all exchanges (diagnostic)
  POST /scan       → trigger a fresh market scan, return results
  POST /backtest   → run a backtest, return results
  POST /trade      → manually place a paper trade
  POST /close      → close an open position
  GET  /trades     → all closed trades + stats
  GET  /health     → liveness ping
  GET  /agent/status        → watchdog status, recent failures, pending patches
  POST /agent/patch/approve → approve (and apply if safe) a queued patch
  POST /agent/patch/reject  → reject a queued patch
  POST /agent/healthcheck   → run health checks immediately
  POST /tradingview/webhook → receive a TradingView Pine alert
  GET  /tradingview/account → account state from connected broker adapter
"""
import json
import logging
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

logger = logging.getLogger(__name__)

_ENGINE = None   # set by main.py before starting server


def _cors(handler):
    handler.send_header("Access-Control-Allow-Origin",  "*")
    handler.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
    handler.send_header("Access-Control-Allow-Headers", "Content-Type")


def _json(handler, data: dict | list, status: int = 200):
    body = json.dumps(data, default=str).encode()
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json")
    handler.send_header("Content-Length", len(body))
    _cors(handler)
    handler.end_headers()
    handler.wfile.write(body)


def _html(handler, content: bytes):
    handler.send_response(200)
    handler.send_header("Content-Type", "text/html; charset=utf-8")
    handler.send_header("Content-Length", len(content))
    _cors(handler)
    handler.end_headers()
    handler.wfile.write(content)


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        logger.debug("[API] %s", fmt % args)

    def do_OPTIONS(self):
        self.send_response(204)
        _cors(self)
        self.end_headers()

    def do_GET(self):
        path = self.path.split("?")[0]

        if path in ("/", "/index.html"):
            html_file = Path(__file__).parent / "index.html"
            if html_file.exists():
                _html(self, html_file.read_bytes())
            else:
                _json(self, {"error": "index.html not found"}, 404)

        elif path == "/health":
            _json(self, {"status": "ok", "exchange": _ENGINE.feed.active_exchange() if _ENGINE else "?"})

        elif path == "/state":
            if _ENGINE:
                _json(self, _ENGINE.get_state())
            else:
                _json(self, {"error": "engine not running"}, 503)

        elif path == "/trades":
            if _ENGINE:
                stats    = _ENGINE.journal.stats()
                closed   = _ENGINE.journal.load_recent(100)
                by_strat = _ENGINE.journal.strategy_stats()
                _json(self, {"stats": stats, "trades": closed, "by_strategy": by_strat})
            else:
                _json(self, {"trades": [], "stats": {}})

        elif path == "/network":
            # Run connection check — may take a few seconds
            try:
                from data.feed import MarketFeed
                from config.settings import EXCHANGE
                feed   = _ENGINE.feed if _ENGINE else MarketFeed(EXCHANGE)
                status = feed.connection_status()
                active = feed.active_exchange()
                _json(self, {"active": active, "exchanges": status})
            except Exception as e:
                _json(self, {"error": str(e)}, 500)

        elif path == "/agent/status":
            if _ENGINE and getattr(_ENGINE, "watchdog", None):
                _json(self, _ENGINE.watchdog.status())
            else:
                _json(self, {"error": "watchdog not running (engine started with --no-watchdog?)"}, 503)

        elif path == "/tradingview/account":
            try:
                from integrations.tradingview.account_state import get_connected_account_state
                _json(self, get_connected_account_state())
            except Exception as e:
                _json(self, {"error": str(e)}, 500)

        elif path == "/settings/weights":
            # Save runtime strategy weights to config (persisted for this session;
            # restart with updated config/settings.py for permanent change).
            try:
                weights = data.get("weights", {})
                if not weights or not isinstance(weights, dict):
                    _json(self, {"error": "weights must be a non-empty dict"}, 400)
                    return
                # Validate keys
                valid_keys = {"macd_ema", "rsi_reversal", "breakout", "scalp", "fib_retracement"}
                bad = set(weights) - valid_keys
                if bad:
                    _json(self, {"error": f"Unknown strategy keys: {bad}"}, 400)
                    return
                # Apply live to engine learner (overrides learned weights for this session)
                if _ENGINE and hasattr(_ENGINE, "learner") and _ENGINE.learner:
                    _ENGINE.learner._weight_override = weights
                    logger.info("[API] /settings/weights — override applied: %s", weights)
                # Also patch the module-level STRATEGY_WEIGHTS so new cycles pick it up
                import config.settings as _cfg
                _cfg.STRATEGY_WEIGHTS = weights
                _json(self, {"ok": True, "weights": weights})
            except Exception as e:
                logger.error("[API] /settings/weights error: %s", e)
                _json(self, {"error": str(e)}, 500)

        elif path == "/settings/config":
            # Read-only config dump for the Settings tab
            try:
                import config.settings as _cfg
                dump = {
                    k: getattr(_cfg, k)
                    for k in dir(_cfg)
                    if not k.startswith("_") and isinstance(getattr(_cfg, k), (int, float, str, bool, dict, list))
                }
                _json(self, dump)
            except Exception as e:
                _json(self, {"error": str(e)}, 500)

        else:
            _json(self, {"error": "not found"}, 404)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body   = self.rfile.read(length) if length else b"{}"
        try:
            data = json.loads(body) if body else {}
        except Exception:
            data = {}

        path = self.path.split("?")[0]

        if path == "/scan":
            from core.scanner   import run_scan
            from data.feed      import MarketFeed
            from config.settings import EXCHANGE
            try:
                feed        = _ENGINE.feed if _ENGINE else MarketFeed(EXCHANGE)
                limit       = int(data.get("limit",   50))
                min_vol     = float(data.get("min_vol", 1_000_000))
                sig_filter  = data.get("signal", "ALL").upper()
                results     = run_scan(feed, limit=limit, min_vol=min_vol, signal_filter=sig_filter)
                # Update engine scan cache (keep raw dfs — engine reuses them)
                if _ENGINE:
                    _ENGINE._scan_cache = results
                # Strip cached raw DataFrames before JSON serialisation —
                # they're internal engine state, not JSON-serialisable.
                clean = [{k: v for k, v in r.items() if not k.startswith("_df_")} for r in results]
                _json(self, {"results": clean, "count": len(clean),
                             "exchange": feed.active_exchange()})
            except Exception as e:
                logger.error("[API] /scan error: %s", e)
                _json(self, {"error": str(e)}, 500)

        elif path == "/backtest":
            from backtest.backtester import Backtester
            from config.settings     import EXCHANGE
            try:
                bt = Backtester(data.get("exchange", EXCHANGE))
                result = bt.run(
                    symbol         = data.get("symbol",   "BTC-USDT-SWAP"),
                    strategy_name  = data.get("strategy", "macd_ema"),
                    tf             = data.get("tf",       "1H"),
                    bars           = int(data.get("bars",    500)),
                    initial_balance= float(data.get("balance", 10000)),
                    risk_pct       = float(data.get("risk_pct", 0.01)),
                )
                _json(self, result)
            except Exception as e:
                logger.error("[API] /backtest error: %s", e)
                _json(self, {"error": str(e)}, 500)

        elif path == "/trade":
            if not _ENGINE:
                _json(self, {"error": "engine not running"}, 503)
                return
            try:
                result = _ENGINE.exec.place_order(
                    symbol   = data["symbol"],
                    side     = data["side"],
                    qty      = float(data["qty"]),
                    price    = float(data["price"]),
                    sl       = float(data["sl"]),
                    tp       = float(data["tp"]),
                    strategy = "manual",
                )
                _json(self, {"ok": True, "result": result})
            except Exception as e:
                _json(self, {"error": str(e)}, 400)

        elif path == "/close":
            if not _ENGINE:
                _json(self, {"error": "engine not running"}, 503)
                return
            try:
                pos_id = data["id"]
                price  = float(data.get("price", 0))
                result = _ENGINE.exec.close_position(pos_id, price, reason="manual_close")
                if result:
                    _ENGINE._on_close(result)
                _json(self, {"ok": True})
            except Exception as e:
                _json(self, {"error": str(e)}, 400)

        elif path == "/paper/reset":
            if not _ENGINE:
                _json(self, {"error": "engine not running"}, 503)
                return
            try:
                balance = data.get("balance", 10_000.0)
                _ENGINE.exec.reset_state(float(balance))
                _json(self, {"ok": True, "balance": balance,
                              "message": f"Paper account reset to ${balance:,.2f}"})
            except Exception as e:
                _json(self, {"error": str(e)}, 500)

        elif path == "/exchange":
            # Hot-switch active exchange at runtime
            if not _ENGINE:
                _json(self, {"error": "engine not running"}, 503)
                return
            try:
                new_ex = data.get("exchange", "").lower()
                if new_ex not in ("okx", "binance", "bybit", "mexc"):
                    _json(self, {"error": f"Unknown exchange: {new_ex}"}, 400)
                    return
                from data.feed import MarketFeed
                _ENGINE.feed = MarketFeed(new_ex)
                logger.info("[API] Exchange switched to %s", new_ex.upper())
                _json(self, {"ok": True, "exchange": new_ex})
            except Exception as e:
                _json(self, {"error": str(e)}, 500)

        elif path == "/agent/patch/approve":
            if not (_ENGINE and getattr(_ENGINE, "watchdog", None)):
                _json(self, {"error": "watchdog not running"}, 503)
                return
            try:
                item = _ENGINE.watchdog.patches.approve(data["id"])
                _json(self, {"ok": True, "patch": item})
            except Exception as e:
                _json(self, {"error": str(e)}, 400)

        elif path == "/agent/patch/reject":
            if not (_ENGINE and getattr(_ENGINE, "watchdog", None)):
                _json(self, {"error": "watchdog not running"}, 503)
                return
            try:
                item = _ENGINE.watchdog.patches.reject(data["id"], note=data.get("note", ""))
                _json(self, {"ok": True, "patch": item})
            except Exception as e:
                _json(self, {"error": str(e)}, 400)

        elif path == "/agent/healthcheck":
            if not (_ENGINE and getattr(_ENGINE, "watchdog", None)):
                _json(self, {"error": "watchdog not running"}, 503)
                return
            try:
                _json(self, _ENGINE.watchdog.run_health_check())
            except Exception as e:
                _json(self, {"error": str(e)}, 500)

        elif path == "/tradingview/webhook":
            try:
                from integrations.tradingview.webhook_server import handle_webhook
                result = handle_webhook(data, engine=_ENGINE, raw_headers=dict(self.headers))
                _json(self, result, 200 if result.get("ok") else 400)
            except Exception as e:
                logger.error("[API] /tradingview/webhook error: %s", e)
                _json(self, {"error": str(e)}, 500)

        elif path == "/settings/weights":
            # Save runtime strategy weights to config (persisted for this session;
            # restart with updated config/settings.py for permanent change).
            try:
                weights = data.get("weights", {})
                if not weights or not isinstance(weights, dict):
                    _json(self, {"error": "weights must be a non-empty dict"}, 400)
                    return
                # Validate keys
                valid_keys = {"macd_ema", "rsi_reversal", "breakout", "scalp", "fib_retracement"}
                bad = set(weights) - valid_keys
                if bad:
                    _json(self, {"error": f"Unknown strategy keys: {bad}"}, 400)
                    return
                # Apply live to engine learner (overrides learned weights for this session)
                if _ENGINE and hasattr(_ENGINE, "learner") and _ENGINE.learner:
                    _ENGINE.learner._weight_override = weights
                    logger.info("[API] /settings/weights — override applied: %s", weights)
                # Also patch the module-level STRATEGY_WEIGHTS so new cycles pick it up
                import config.settings as _cfg
                _cfg.STRATEGY_WEIGHTS = weights
                _json(self, {"ok": True, "weights": weights})
            except Exception as e:
                logger.error("[API] /settings/weights error: %s", e)
                _json(self, {"error": str(e)}, 500)

        elif path == "/settings/config":
            # Read-only config dump for the Settings tab
            try:
                import config.settings as _cfg
                dump = {
                    k: getattr(_cfg, k)
                    for k in dir(_cfg)
                    if not k.startswith("_") and isinstance(getattr(_cfg, k), (int, float, str, bool, dict, list))
                }
                _json(self, dump)
            except Exception as e:
                _json(self, {"error": str(e)}, 500)

        else:
            _json(self, {"error": "not found"}, 404)


def start_server(engine, host: str = "0.0.0.0", port: int = 8080):
    global _ENGINE
    _ENGINE = engine
    server  = HTTPServer((host, port), _Handler)
    logger.info("[API] Server running at http://%s:%d", host, port)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    return server
